from src.http_response_models import ProblemDetailModel



class ModelFactory:
    pass
